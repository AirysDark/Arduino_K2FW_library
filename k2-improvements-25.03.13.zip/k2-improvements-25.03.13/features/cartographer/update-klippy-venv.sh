#!/bin/sh

source klippy-venv/bin/activate

wget https://bootstrap.pypa.io/get-pip.py
python ./get-pip.py
