# Obico

## Why

I'll let the Obico folks speak for themselves, [here](https://www.obico.io/)
