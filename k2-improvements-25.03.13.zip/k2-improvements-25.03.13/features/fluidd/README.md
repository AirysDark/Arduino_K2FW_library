# Why

The version of Fluidd provided on the K2 is old (v1.30.0-f3e4ac3, 2024-05-01) and _does not_ support the camera on the K2.
