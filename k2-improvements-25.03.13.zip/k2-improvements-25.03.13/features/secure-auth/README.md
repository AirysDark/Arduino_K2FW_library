# Secure Auth

## Why?

The Creality K2 has a well known username and password for remote SSH access.

Provided there is a [key configured for ssh authentication](./SETUP.md), this disables all password ssh authentication.
