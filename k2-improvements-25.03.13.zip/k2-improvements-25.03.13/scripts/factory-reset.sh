echo "all" | /usr/bin/nc -U /var/run/wipe.sock
