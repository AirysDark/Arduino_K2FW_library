# Doxygen API Docs

Generate HTML docs locally:

```bash
# from repo root
doxygen docs/doxygen/Doxyfile
```

Output:
- `docs_out/html/index.html`

Recommended (Windows):
- Install Doxygen + Graphviz
- Run the command from PowerShell or cmd in repo root
